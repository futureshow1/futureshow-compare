# 🛡️ Anonimizator

Lokalne narzędzie do anonimizacji dokumentów (jak [beznazwisk.pl](https://beznazwisk.pl)),
napisane pod macOS. Wykrywa dane osobowe w plikach **PDF / DOCX / TXT** lub we
wklejonym tekście, zamienia je na neutralne tokeny (`[OSOBA_1]`, `[PESEL_1]`…),
a po pracy z AI potrafi **przywrócić oryginalne dane**.

**Wszystko dzieje się na Twoim komputerze.** Nic nie jest wysyłane do internetu —
identyfikatory rozpoznają reguły po stronie serwera, a nazwiska i adresy lokalny
model **Bielik** (przez Ollamę).

---

## Po co to

Chcesz skorzystać z AI (Claude, ChatGPT) przy dokumencie zawierającym dane
wrażliwe — np. protokole z mediacji — ale nie możesz wysłać tam PESEL-i i nazwisk
(RODO). Workflow:

1. **Anonimizujesz** dokument → dostajesz tekst z tokenami + plik mapowania (klucz).
2. Wklejasz tekst z tokenami do dowolnego AI i pracujesz normalnie.
3. Odpowiedź AI wklejasz z powrotem → **deanonimizacja** odtwarza prawdziwe dane.

## Instalacja (raz)

Dwuklik na **`Instalator.command`**. Przeprowadzi Cię przez całość i — za Twoją
zgodą — pobierze oraz zainstaluje wszystko, co potrzebne:

- **Pythona** (jeśli go nie masz — przez Homebrew lub oficjalny pakiet python.org).
  Biblioteki aplikacji (Flask, pypdf) są **dołączone w paczce** (folder `wheels/`),
  więc instalują się bez internetu,
- **Ollamę** (program uruchamiający model), jeśli jej nie masz,
- **model Bielik** (~6,7 GB) do rozpoznawania nazwisk.

Każde większe pobranie wymaga potwierdzenia (wpisujesz `t`). Wszystkie kroki są
opcjonalne — jeśli pominiesz Bielika, aplikacja działa w trybie słownikowym.

> Przy pierwszym otwarciu macOS może ostrzec, że plik pochodzi z internetu.
> Kliknij plik **prawym przyciskiem → Otwórz → Otwórz**.

**Wymagania:** macOS + Python 3 (zwykle już jest; instalator pomoże go doinstalować).

## Codzienne uruchamianie

Dwuklik na **`start.command`** — przygotuje środowisko (jeśli trzeba), w razie
potrzeby podniesie Ollamę i otworzy aplikację pod `http://127.0.0.1:8143`.

## Co wykrywa

| Deterministycznie (reguły + sumy kontrolne) | Model Bielik / słownik |
|---|---|
| PESEL, NIP, REGON, nr dowodu, nr paszportu | imiona i nazwiska (z odmianą) |
| nr konta / IBAN, telefon, e-mail | organizacje i firmy |
| kod pocztowy, KRS, adres (ul./al./pl.) | miasta i miejscowości |
| data, tablica rejestracyjna *(domyślnie wył.)* | adresy |

Przed zapisem zawsze widzisz **podgląd z podświetleniami** — kliknięciem wyłączasz
ewentualne pomyłki, a w panelu obok możesz dodać własne frazy do ukrycia.

## Pliki wyjściowe

- `…_anon.txt` — tekst z tokenami (to wklejasz do AI),
- `…_anon.docx` — gdy wejściem był DOCX: zachowuje formatowanie,
- `…_mapowanie.json` — **klucz** do przywrócenia danych,
- `…_raport.txt` — czytelna tabela: token → oryginał.

> 🔑 Plik `…_mapowanie.json` zawiera oryginalne dane. Trzymaj go bezpiecznie i
> **nigdy nie wysyłaj do AI.** Do modelu trafia wyłącznie tekst z tokenami.

## Ograniczenia (warto wiedzieć)

- Rozpoznawanie nazwisk nigdy nie jest w 100% pewne — **zawsze przejrzyj podgląd**.
  Twarde identyfikatory (PESEL, NIP…) łapane są niezawodnie dzięki sumom kontrolnym.
- **Tryb słownikowy** (bez Bielika) dobrze radzi sobie z typowymi polskimi nazwiskami
  i ich odmianą oraz ze wszystkimi twardymi danymi — dla większości dokumentów wystarcza,
  bez żadnego pobierania. **Bielik** dokłada nazwiska rzadkie/obcojęzyczne, nazwy firm
  i miejscowości — warto go włączyć przy trudniejszych tekstach.
- W DOCX anonimizowana jest treść główna; nagłówki/stopki nie są jeszcze przetwarzane.
- PDF jest odczytywany jako tekst (bez odtwarzania układu); skany wymagałyby OCR.

## Struktura

```
anonimizator/
├── start.command         ← uruchamianie jednym kliknięciem
├── app.py                ← serwer (Flask)
├── requirements.txt
├── engine/
│   ├── categories.py     ← kategorie danych + priorytety
│   ├── regex_rules.py    ← reguły + sumy kontrolne (PESEL/NIP/REGON/dowód)
│   ├── dictionaries.py   ← słownik imion/nazwisk (tryb awaryjny)
│   ├── ner_bielik.py     ← klient Bielika (Ollama) + ekspansja odmian
│   ├── anonymizer.py     ← rdzeń: tokeny, mapowanie, deanonimizacja
│   └── io_files.py       ← odczyt/zapis PDF, DOCX, TXT
├── wheels/               ← biblioteki do instalacji offline (Flask, pypdf, markupsafe)
├── static/               ← interfejs (HTML/CSS/JS)
└── przyklady/            ← przykładowy tekst + skrypty testowe (_smoke_*.py)
```

Testy potoku: `./.venv/bin/python przyklady/_smoke_full.py`
(wymaga uruchomionej Ollamy z Bielikiem).

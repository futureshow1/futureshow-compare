"use strict";

// Kolory podświetleń wg kategorii (jasne tła, ciemny tekst).
const COLORS = {
  OSOBA: "#ffd9a0", NAZWISKO: "#ffd9a0", IMIE: "#ffe9c7",
  FIRMA: "#cfe8ff", ADRES: "#d6f0cf", MIEJSCE: "#e6dcff",
  PESEL: "#ffc9c9", NIP: "#ffd0c0", REGON: "#ffd6c0", DOWOD: "#ffd0e0", PASZPORT: "#ffd0e0",
  IBAN: "#ffe0b3", TELEFON: "#cdeede", EMAIL: "#cfeaff", KOD_POCZTOWY: "#dfe6ef",
  KRS: "#f0d9b8", DATA: "#e6e6e6", TABLICA: "#e6e6e6", INNE: "#f5cdef",
};
const colorFor = (c) => COLORS[c] || "#e0e0e0";

let INFO = null;
let STATE = null;            // {text, spans, file_id, kind}
let DISABLED = new Set();    // id-y spanów wyłączonych przez użytkownika
let manualCounter = 0;
let MAPPING = null;          // wczytane mapowanie do deanonimizacji

const $ = (id) => document.getElementById(id);

// --------------------------------------------------------------------------
// Inicjalizacja
// --------------------------------------------------------------------------
async function init() {
  setupTabs();
  setupInput();
  setupButtons();
  try {
    INFO = await (await fetch("/api/info")).json();
  } catch (e) {
    setStatus("błąd połączenia z serwerem", "fallback");
    return;
  }
  $("modelName").textContent = INFO.model || "";
  if (INFO.bielik_available) {
    setStatus("Bielik gotowy — " + INFO.model, "ok");
  } else {
    setStatus("tryb słownikowy (Bielik/Ollama niedostępny)", "fallback");
    $("useBielik").checked = false;
    $("useBielik").disabled = true;
  }
  buildCatChips();
}

function setStatus(text, kind) {
  const el = $("status");
  el.textContent = text;
  el.className = "status status--" + kind;
}

function setupTabs() {
  document.querySelectorAll(".tab").forEach((t) => {
    t.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((x) => x.classList.remove("is-active"));
      document.querySelectorAll(".panel").forEach((x) => x.classList.remove("is-active"));
      t.classList.add("is-active");
      $("panel-" + t.dataset.tab).classList.add("is-active");
    });
  });
}

function buildCatChips() {
  const box = $("catChips");
  box.innerHTML = "";
  const def = new Set(INFO.default_enabled);
  Object.entries(INFO.categories).forEach(([key, meta]) => {
    if (key === "INNE") return; // ręczne maski nie są kategorią do wykrywania
    const chip = document.createElement("span");
    chip.className = "chip" + (def.has(key) ? " on" : "");
    chip.dataset.key = key;
    chip.innerHTML = `<span class="dot" style="width:9px;height:9px;border-radius:50%;background:${colorFor(key)}"></span>${meta.label}`;
    chip.addEventListener("click", () => chip.classList.toggle("on"));
    box.appendChild(chip);
  });
}

function enabledCategories() {
  return [...document.querySelectorAll("#catChips .chip.on")].map((c) => c.dataset.key);
}

// --------------------------------------------------------------------------
// Wejście: plik / drag-drop
// --------------------------------------------------------------------------
let pickedFile = null;

function setupInput() {
  const dz = $("dropzone");
  const fi = $("fileInput");
  $("btnPick").addEventListener("click", () => fi.click());
  fi.addEventListener("change", () => { if (fi.files[0]) setFile(fi.files[0]); });

  ["dragenter", "dragover"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("drag"); }));
  ["dragleave", "drop"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("drag"); }));
  dz.addEventListener("drop", (e) => {
    if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
  });
}

function setFile(file) {
  pickedFile = file;
  $("fileName").textContent = "📄 " + file.name;
  $("pasteText").value = "";
}

function setupButtons() {
  $("pasteText").addEventListener("input", () => {
    if ($("pasteText").value) { pickedFile = null; $("fileName").textContent = ""; $("fileInput").value = ""; }
  });
  $("btnDetect").addEventListener("click", detect);
  $("btnAnonymize").addEventListener("click", anonymize);
  $("btnManual").addEventListener("click", addManual);
  $("manualTerm").addEventListener("keydown", (e) => { if (e.key === "Enter") addManual(); });
  $("btnCopyAnon").addEventListener("click", () => copy($("anonText").value, $("btnCopyAnon")));
  $("btnCopyDeanon").addEventListener("click", () => copy($("deanonOut").value, $("btnCopyDeanon")));
  $("mapFile").addEventListener("change", loadMapping);
  $("btnDeanon").addEventListener("click", deanonymize);
}

// --------------------------------------------------------------------------
// Wykrywanie
// --------------------------------------------------------------------------
async function detect() {
  const useBielik = $("useBielik").checked;
  const enabled = enabledCategories();
  if (!pickedFile && !$("pasteText").value.trim()) {
    $("detectStatus").textContent = "Najpierw wczytaj plik lub wklej tekst.";
    return;
  }
  $("btnDetect").disabled = true;
  $("detectStatus").textContent = useBielik
    ? "Analizuję… Bielik liczy lokalnie, przy dłuższych dokumentach to nawet kilkadziesiąt sekund."
    : "Analizuję…";

  try {
    let res;
    if (pickedFile) {
      const fd = new FormData();
      fd.append("file", pickedFile);
      fd.append("use_bielik", useBielik ? "true" : "false");
      enabled.forEach((c) => fd.append("enabled", c));
      res = await fetch("/api/detect", { method: "POST", body: fd });
    } else {
      res = await fetch("/api/detect", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: $("pasteText").value, use_bielik: useBielik, enabled }),
      });
    }
    const data = await res.json();
    if (data.error) throw new Error(data.error);

    STATE = { text: data.text, spans: data.spans, file_id: data.file_id, kind: data.kind };
    DISABLED = new Set();
    manualCounter = 0;
    $("detectStatus").textContent = "";
    renderResults(data.info);
  } catch (e) {
    $("detectStatus").textContent = "⚠️ " + e.message;
  } finally {
    $("btnDetect").disabled = false;
  }
}

function renderResults(info) {
  const src = info && info.bielik ? "Bielik" : "słownik (tryb awaryjny)";
  $("summary").textContent =
    `Znaleziono ${STATE.spans.length} fragmentów do anonimizacji. Rozpoznawanie nazwisk: ${src}.`;
  $("results").classList.remove("hidden");
  $("anonResult").classList.add("hidden");
  renderPreview();
  renderCatList();
  $("results").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function activeSpans() {
  // Spany do wyświetlenia: posortowane, bez nakładek (na potrzeby podglądu).
  const sorted = [...STATE.spans].sort((a, b) => a.start - b.start || b.end - a.end);
  const out = [];
  let last = -1;
  for (const s of sorted) {
    if (s.start < last) continue; // pomiń nakładkę w podglądzie
    out.push(s);
    last = s.end;
  }
  return out;
}

function renderPreview() {
  const pre = $("preview");
  pre.innerHTML = "";
  const text = STATE.text;
  let cursor = 0;
  for (const s of activeSpans()) {
    if (s.start > cursor) pre.appendChild(document.createTextNode(text.slice(cursor, s.start)));
    const m = document.createElement("mark");
    const off = DISABLED.has(s.id);
    m.className = "pii" + (off ? " off" : "");
    m.style.background = colorFor(s.category);
    m.title = (INFO.categories[s.category] ? INFO.categories[s.category].label : s.category)
      + (off ? " — wyłączone" : " — kliknij, aby wyłączyć");
    m.textContent = text.slice(s.start, s.end);
    m.addEventListener("click", () => {
      if (DISABLED.has(s.id)) DISABLED.delete(s.id); else DISABLED.add(s.id);
      renderPreview(); renderCatList();
    });
    pre.appendChild(m);
    cursor = s.end;
  }
  if (cursor < text.length) pre.appendChild(document.createTextNode(text.slice(cursor)));
}

function renderCatList() {
  const box = $("catList");
  box.innerHTML = "";
  const byCat = {};
  STATE.spans.forEach((s) => {
    byCat[s.category] = byCat[s.category] || { total: 0, off: 0 };
    byCat[s.category].total++;
    if (DISABLED.has(s.id)) byCat[s.category].off++;
  });
  Object.entries(byCat).sort().forEach(([cat, c]) => {
    const row = document.createElement("label");
    row.className = "catrow";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = c.off < c.total; // zaznaczone, gdy choć jeden aktywny
    cb.addEventListener("change", () => {
      STATE.spans.forEach((s) => {
        if (s.category !== cat) return;
        if (cb.checked) DISABLED.delete(s.id); else DISABLED.add(s.id);
      });
      renderPreview(); renderCatList();
    });
    const sw = document.createElement("span");
    sw.className = "swatch"; sw.style.background = colorFor(cat);
    const label = document.createElement("span");
    label.textContent = INFO.categories[cat] ? INFO.categories[cat].label : cat;
    const cnt = document.createElement("span");
    cnt.className = "cnt"; cnt.textContent = c.total;
    row.append(cb, sw, label, cnt);
    box.appendChild(row);
  });
}

function addManual() {
  const term = $("manualTerm").value.trim();
  if (!term || !STATE) return;
  const text = STATE.text;
  let added = 0;
  const findAll = (hay, needle, ci) => {
    const res = [];
    const H = ci ? hay.toLowerCase() : hay;
    const N = ci ? needle.toLowerCase() : needle;
    let i = H.indexOf(N);
    while (i !== -1) { res.push(i); i = H.indexOf(N, i + N.length); }
    return res;
  };
  let positions = findAll(text, term, false);
  if (positions.length === 0) positions = findAll(text, term, true);
  positions.forEach((p) => {
    const id = "m" + (manualCounter++);
    STATE.spans.push({ id, start: p, end: p + term.length,
      surface: text.slice(p, p + term.length), category: "INNE", source: "manual" });
    added++;
  });
  $("manualTerm").value = "";
  if (added === 0) { $("detectStatus").textContent = `Nie znaleziono „${term}" w tekście.`; }
  renderPreview(); renderCatList();
}

// --------------------------------------------------------------------------
// Anonimizacja
// --------------------------------------------------------------------------
async function anonymize() {
  if (!STATE) return;
  const spans = STATE.spans.filter((s) => !DISABLED.has(s.id))
    .map((s) => ({ start: s.start, end: s.end, surface: s.surface, category: s.category, group: s.group }));
  $("btnAnonymize").disabled = true;
  try {
    const res = await fetch("/api/anonymize", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file_id: STATE.file_id, text: STATE.text, spans }),
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    $("anonText").value = data.anon_text;
    $("anonCount").textContent = `· ${data.count} bytów zanonimizowanych`;
    const dl = $("downloads");
    dl.innerHTML = "";
    data.downloads.forEach((d) => {
      const a = document.createElement("a");
      a.href = d.url; a.textContent = "⬇ " + d.name; a.setAttribute("download", d.name);
      dl.appendChild(a);
    });
    $("anonResult").classList.remove("hidden");
    $("anonResult").scrollIntoView({ behavior: "smooth", block: "nearest" });
  } catch (e) {
    alert("Błąd: " + e.message);
  } finally {
    $("btnAnonymize").disabled = false;
  }
}

// --------------------------------------------------------------------------
// Deanonimizacja
// --------------------------------------------------------------------------
function loadMapping() {
  const f = $("mapFile").files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      MAPPING = JSON.parse(r.result);
      $("mapStatus").textContent = `wczytano (${Object.keys(MAPPING).length} tokenów)`;
    } catch (e) {
      MAPPING = null;
      $("mapStatus").textContent = "⚠️ nieprawidłowy plik JSON";
    }
  };
  r.readAsText(f);
}

async function deanonymize() {
  const text = $("aiText").value;
  if (!text.trim()) { $("deanonStatus").textContent = "Wklej tekst z tokenami."; return; }
  if (!MAPPING) { $("deanonStatus").textContent = "Wczytaj plik mapowania (*_mapowanie.json)."; return; }
  $("deanonStatus").textContent = "";
  try {
    const res = await fetch("/api/deanonymize", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, mapping: MAPPING }),
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    $("deanonOut").value = data.text;
    $("deanonOutWrap").classList.remove("hidden");
  } catch (e) {
    $("deanonStatus").textContent = "⚠️ " + e.message;
  }
}

function copy(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    const old = btn.textContent;
    btn.textContent = "Skopiowano ✓";
    setTimeout(() => (btn.textContent = old), 1400);
  });
}

init();

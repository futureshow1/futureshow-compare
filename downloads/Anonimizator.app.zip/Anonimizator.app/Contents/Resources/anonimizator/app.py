"""Anonimizator — lokalny serwer aplikacji.

Wszystko działa na Twoim komputerze. Tekst i pliki nie są nigdzie wysyłane;
nazwiska rozpoznaje lokalny model Bielik (Ollama), a identyfikatory — reguły
po stronie serwera. Uruchom przez ./start.command i otwórz http://127.0.0.1:8143
"""

import io
import json
import os
import uuid
import webbrowser
from collections import OrderedDict
from threading import Timer

from flask import Flask, request, jsonify, send_file, send_from_directory, abort

from engine import anonymizer, io_files, ner_bielik
from engine.categories import CATEGORY_META, default_enabled

HOST = "127.0.0.1"
PORT = 8143
HERE = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__, static_folder=os.path.join(HERE, "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024  # 40 MB

# Pamięć podręczna (proces lokalny, jeden użytkownik).
UPLOADS = OrderedDict()   # file_id -> {kind, filename, data, text}
RESULTS = OrderedDict()   # result_id -> {filename: bytes}

DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


def _cache_put(store, key, value, cap=20):
    store[key] = value
    while len(store) > cap:
        store.popitem(last=False)


def _enabled_from(raw):
    if not raw:
        return default_enabled()
    return set(raw) & set(CATEGORY_META.keys())


# --------------------------------------------------------------------------
# Strony / informacje
# --------------------------------------------------------------------------

@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/info")
def api_info():
    model = ner_bielik.find_bielik_model() or ner_bielik.DEFAULT_MODEL
    return jsonify({
        "categories": CATEGORY_META,
        "default_enabled": sorted(default_enabled()),
        "bielik_available": ner_bielik.available(),
        "model": model,
        "models": ner_bielik.list_models(),
    })


# --------------------------------------------------------------------------
# Wykrywanie
# --------------------------------------------------------------------------

@app.post("/api/detect")
def api_detect():
    try:
        if "file" in request.files and request.files["file"].filename:
            f = request.files["file"]
            data = f.read()
            kind, text = io_files.read_any(f.filename, data)
            use_bielik = request.form.get("use_bielik", "true") == "true"
            enabled = _enabled_from(request.form.getlist("enabled") or None)
            file_id = uuid.uuid4().hex
            _cache_put(UPLOADS, file_id, {
                "kind": kind, "filename": f.filename, "data": data, "text": text,
            })
        else:
            body = request.get_json(force=True, silent=True) or {}
            text = body.get("text", "") or ""
            kind = "txt"
            use_bielik = bool(body.get("use_bielik", True))
            enabled = _enabled_from(body.get("enabled"))
            file_id = None
            f = None

        if not text.strip():
            return jsonify({"error": "Brak tekstu do analizy."}), 400

        spans, info = anonymizer.detect(text, enabled=enabled, use_bielik=use_bielik)
        return jsonify({
            "file_id": file_id,
            "kind": kind,
            "filename": (f.filename if f else None),
            "text": text,
            "spans": spans,
            "info": info,
        })
    except Exception as e:
        return jsonify({"error": "Błąd analizy: %s" % e}), 500


# --------------------------------------------------------------------------
# Anonimizacja
# --------------------------------------------------------------------------

@app.post("/api/anonymize")
def api_anonymize():
    try:
        body = request.get_json(force=True, silent=True) or {}
        file_id = body.get("file_id")
        spans = body.get("spans") or []

        if file_id and file_id in UPLOADS:
            up = UPLOADS[file_id]
            text = up["text"]
            kind = up["kind"]
            src_name = up["filename"] or "dokument"
        else:
            text = body.get("text", "") or ""
            kind = "txt"
            src_name = "tekst"

        # Oczyść spany do niezbędnych pól.
        clean = []
        for s in spans:
            try:
                clean.append({
                    "start": int(s["start"]), "end": int(s["end"]),
                    "surface": s.get("surface", text[int(s["start"]):int(s["end"])]),
                    "category": s["category"],
                    "group": s.get("group"),
                })
            except (KeyError, ValueError, TypeError):
                continue

        anon, mapping, spans_tok = anonymizer.anonymize(text, clean)
        report = anonymizer.make_report(mapping)

        base = os.path.splitext(os.path.basename(src_name))[0] or "dokument"
        files = {
            base + "_anon.txt": anon.encode("utf-8"),
            base + "_mapowanie.json": json.dumps(
                mapping, ensure_ascii=False, indent=2).encode("utf-8"),
            base + "_raport.txt": report.encode("utf-8"),
        }
        if file_id and kind == "docx":
            try:
                files[base + "_anon.docx"] = io_files.docx_rebuild(
                    UPLOADS[file_id]["data"], spans_tok)
            except Exception as e:
                files[base + "_UWAGA.txt"] = (
                    "Nie udało się odtworzyć DOCX (%s). "
                    "Użyj wersji .txt." % e).encode("utf-8")

        rid = uuid.uuid4().hex
        _cache_put(RESULTS, rid, files)
        downloads = [
            {"name": name, "url": "/api/download/%s/%d" % (rid, i)}
            for i, name in enumerate(files.keys())
        ]
        return jsonify({
            "anon_text": anon,
            "mapping": mapping,
            "report": report,
            "count": len(mapping),
            "downloads": downloads,
        })
    except Exception as e:
        return jsonify({"error": "Błąd anonimizacji: %s" % e}), 500


@app.get("/api/download/<rid>/<int:idx>")
def api_download(rid, idx):
    files = RESULTS.get(rid)
    if not files:
        abort(404)
    names = list(files.keys())
    if idx < 0 or idx >= len(names):
        abort(404)
    name = names[idx]
    data = files[name]
    mime = (DOCX_MIME if name.endswith(".docx")
            else "application/json" if name.endswith(".json")
            else "text/plain; charset=utf-8")
    return send_file(io.BytesIO(data), download_name=name,
                     as_attachment=True, mimetype=mime)


# --------------------------------------------------------------------------
# Deanonimizacja
# --------------------------------------------------------------------------

@app.post("/api/deanonymize")
def api_deanonymize():
    try:
        body = request.get_json(force=True, silent=True) or {}
        text = body.get("text", "") or ""
        mapping = body.get("mapping") or {}
        if isinstance(mapping, str):
            mapping = json.loads(mapping)
        if not text.strip():
            return jsonify({"error": "Brak tekstu do deanonimizacji."}), 400
        if not mapping:
            return jsonify({"error": "Brak mapowania (wczytaj plik *_mapowanie.json)."}), 400
        restored = anonymizer.deanonymize(text, mapping)
        return jsonify({"text": restored})
    except Exception as e:
        return jsonify({"error": "Błąd deanonimizacji: %s" % e}), 500


def _open_browser():
    try:
        webbrowser.open("http://%s:%d" % (HOST, PORT))
    except Exception:
        pass


if __name__ == "__main__":
    if os.environ.get("ANON_OPEN", "0") == "1":
        Timer(1.2, _open_browser).start()
    app.run(host=HOST, port=PORT, threaded=True, debug=False)

#!/bin/bash
# ============================================================
#  Anonimizator — Instalator (macOS)
#  Sprawdza i instaluje wszystko, co potrzebne. Pyta o zgodę
#  tam, gdzie pobiera większe rzeczy (Ollama, model Bielik).
#  Wszystko działa lokalnie; do internetu sięga tylko po to,
#  co zatwierdzisz.
# ============================================================
set -u
cd "$(dirname "$0")" || exit 1

ASSUME_YES="${ANON_ASSUME_YES:-0}"   # 1 = nie pytaj (do testów/automatyzacji)
NO_LAUNCH="${ANON_NO_LAUNCH:-0}"     # 1 = nie uruchamiaj aplikacji na końcu

BIELIK_TAG="SpeakLeash/bielik-11b-v3.0-instruct:Q4_K_M"
OLLAMA_ZIP="https://ollama.com/download/Ollama-darwin.zip"
PY_PKG_URL="https://www.python.org/ftp/python/3.12.10/python-3.12.10-macos11.pkg"

green()  { printf "\033[32m%s\033[0m\n" "$1"; }
yellow() { printf "\033[33m%s\033[0m\n" "$1"; }
red()    { printf "\033[31m%s\033[0m\n" "$1"; }
hr()     { printf "%s\n" "------------------------------------------------------------"; }

ask() {  # $1 = pytanie ; zwraca 0, gdy "tak"
  if [ "$ASSUME_YES" = "1" ]; then return 0; fi
  local ans
  read -r -p "$1 [t/N]: " ans || return 1
  case "$ans" in [tTyY]*) return 0 ;; *) return 1 ;; esac
}

pause_exit() { echo ""; read -r -p "Naciśnij Enter, aby zamknąć…" _ 2>/dev/null || true; exit "${1:-0}"; }

OLLAMA_BIN=""
find_ollama() {
  if command -v ollama >/dev/null 2>&1; then
    OLLAMA_BIN="ollama"
  elif [ -x /Applications/Ollama.app/Contents/Resources/ollama ]; then
    OLLAMA_BIN="/Applications/Ollama.app/Contents/Resources/ollama"
  else
    OLLAMA_BIN=""
  fi
}
ollama_up() { curl -s --max-time 3 http://localhost:11434/api/tags >/dev/null 2>&1; }

PY=""
find_python() {  # ustawia PY na działający python3 (z modułem venv) albo zwraca 1
  for cand in python3 /opt/homebrew/bin/python3 /usr/local/bin/python3 \
              /Library/Frameworks/Python.framework/Versions/Current/bin/python3; do
    if command -v "$cand" >/dev/null 2>&1 && "$cand" -c 'import venv,sys' >/dev/null 2>&1; then
      PY="$cand"; return 0
    fi
  done
  PY=""; return 1
}

clear
hr
echo "  INSTALATOR ANONIMIZATORA"
hr
echo ""
echo "  Co zrobi instalator (każde większe pobranie pyta o zgodę):"
echo "    1) sprawdzi Pythona i — jeśli trzeba — pomoże go zainstalować,"
echo "    2) przygotuje aplikację (kilkanaście sekund),"
echo "    3) opcjonalnie pobierze model Bielik do rozpoznawania nazwisk,"
echo "    4) uruchomi program w przeglądarce."
echo ""
echo "  • Wszystko działa lokalnie — Twoje dokumenty nie wychodzą do internetu."
echo "  • Bez Bielika program też działa (tryb słownikowy) i jest gotowy od razu."
echo "  • Bielik daje lepsze nazwiska/firmy/miasta, ale waży ~6,7 GB i pobranie"
echo "    może potrwać kilka–kilkanaście minut. Możesz go pominąć i dodać później."
echo ""
echo "  Uwaga: gdyby macOS ostrzegał, że plik jest 'z internetu' — kliknij go"
echo "  prawym przyciskiem → Otwórz → Otwórz (wystarczy raz)."
echo ""
if [ "$ASSUME_YES" != "1" ] && [ "${ANON_MOVED:-0}" != "1" ]; then
  read -r -p "  Naciśnij Enter, aby rozpocząć (albo zamknij okno, by przerwać)… " _ 2>/dev/null || true
fi
echo ""

# ---------- Lokalizacja instalacji ----------
# Skrypty same się lokalizują (dirname "$0" / __file__), więc po przeniesieniu
# całego folderu wszystko pozostaje spójne. Tu pytamy tylko, GDZIE ma leżeć.
if [ "${ANON_MOVED:-0}" != "1" ]; then
  DEST=""
  if [ -n "${ANON_DEST:-}" ]; then
    DEST="$ANON_DEST"
  elif [ "$ASSUME_YES" != "1" ]; then
    echo "  Gdzie zainstalować Anonimizator?"
    echo "    1) Tutaj, gdzie leży teraz ten folder   (zalecane)"
    echo "    2) W Aplikacjach:  /Applications/Anonimizator"
    echo "    3) Wskażę własny folder"
    read -r -p "  Wybór [1/2/3, Enter = 1]: " _loc 2>/dev/null || _loc="1"
    case "$_loc" in
      2) DEST="/Applications/Anonimizator" ;;
      3) read -r -p "  Podaj pełną ścieżkę docelową: " DEST 2>/dev/null || DEST="" ;;
    esac
  fi
  if [ -n "$DEST" ] && [ "$DEST" != "$(pwd)" ]; then
    echo "  Kopiuję pliki do: $DEST"
    if mkdir -p "$DEST" 2>/dev/null && rsync -a --exclude='.venv' "$(pwd)/" "$DEST/" 2>/dev/null; then
      green "  ✓ Skopiowano — kontynuuję z nowej lokalizacji."
      exec env ANON_MOVED=1 ANON_ASSUME_YES="$ASSUME_YES" ANON_NO_LAUNCH="$NO_LAUNCH" "$DEST/Instalator.command"
    else
      red "  Nie udało się zapisać w '$DEST' — instaluję w bieżącym folderze."
    fi
  fi
  echo ""
fi

# ---------- 1/4  Python 3 ----------
echo "[1/4] Sprawdzam Pythona 3…"
if ! find_python; then
  yellow "  Nie znaleziono działającego Pythona 3 — jest niezbędny."
  # 1) Homebrew, jeśli jest (bez hasła administratora)
  if command -v brew >/dev/null 2>&1 && ask "  Zainstalować Pythona przez Homebrew?"; then
    brew install python && find_python
  fi
  # 2) Oficjalny pakiet z python.org (poprosi o hasło administratora)
  if [ -z "$PY" ] && ask "  Pobrać i zainstalować Pythona z python.org? (poprosi o hasło administratora)"; then
    echo "  Pobieram instalator Pythona…"
    if curl -L --fail -o /tmp/python-anon.pkg "$PY_PKG_URL"; then
      echo "  Instaluję Pythona — podaj hasło administratora, jeśli pojawi się prośba…"
      sudo installer -pkg /tmp/python-anon.pkg -target / && find_python
    else
      red "  Nie udało się pobrać Pythona."
    fi
  fi
  # 3) Ostatecznie: strona do ręcznej instalacji
  if [ -z "$PY" ]; then
    yellow "  Otwieram stronę Pythona — zainstaluj ręcznie i uruchom ten plik ponownie."
    open "https://www.python.org/downloads/macos/" 2>/dev/null || true
    pause_exit 1
  fi
fi
green "  ✓ Python: $("$PY" --version 2>&1)"

# ---------- 2/4  Środowisko + zależności ----------
echo ""
echo "[2/4] Przygotowuję środowisko aplikacji…"
if [ ! -d ".venv" ]; then
  "$PY" -m venv .venv || { red "  Nie udało się utworzyć środowiska."; pause_exit 1; }
fi
if [ -d wheels ] && ./.venv/bin/python -m pip install -q --no-index --find-links wheels -r requirements.txt >/tmp/anon_pip.log 2>&1; then
  green "  ✓ Zależności gotowe (offline, z paczki)"
elif ./.venv/bin/python -m pip install -q -r requirements.txt >>/tmp/anon_pip.log 2>&1; then
  green "  ✓ Zależności gotowe (pobrane z internetu)"
else
  red "  Błąd instalacji zależności. Szczegóły: /tmp/anon_pip.log"; pause_exit 1
fi

# ---------- 3/4  Ollama + Bielik (opcjonalnie, za zgodą) ----------
echo ""
echo "[3/4] Lokalny model Bielik — rozpoznaje nazwiska, firmy i adresy"
echo "      (radzi sobie z polską odmianą). Bez niego aplikacja działa,"
echo "      ale w słabszym trybie słownikowym."
echo ""
if ask "  Skonfigurować teraz Bielika? (opcjonalne; Enter = pomiń i dodaj później)"; then

  find_ollama
  # 3a. Ollama (silnik modeli)
  if [ -z "$OLLAMA_BIN" ]; then
    yellow "  Nie znaleziono Ollamy (program uruchamiający Bielika)."
    if command -v brew >/dev/null 2>&1 && ask "  Zainstalować Ollamę przez Homebrew?"; then
      brew install ollama && find_ollama
    elif ask "  Pobrać Ollamę z ollama.com (~kilkaset MB) i zainstalować w /Applications?"; then
      echo "  Pobieram Ollamę…"
      if curl -L --fail -o /tmp/Ollama-darwin.zip "$OLLAMA_ZIP"; then
        ditto -x -k /tmp/Ollama-darwin.zip /Applications/ 2>/dev/null \
          || unzip -o /tmp/Ollama-darwin.zip -d /Applications >/dev/null 2>&1
        xattr -dr com.apple.quarantine /Applications/Ollama.app 2>/dev/null || true
        find_ollama
        [ -n "$OLLAMA_BIN" ] && green "  ✓ Ollama zainstalowana" || red "  Instalacja Ollamy nie powiodła się."
      else
        red "  Nie udało się pobrać Ollamy. Pominę — zadziała tryb słownikowy."
      fi
    else
      yellow "  Pomijam Ollamę — zadziała tryb słownikowy."
    fi
  else
    green "  ✓ Ollama już jest"
  fi

  # 3b. Usługa Ollamy
  if [ -n "$OLLAMA_BIN" ] && ! ollama_up; then
    echo "  Uruchamiam usługę Ollamy…"
    if [ -d /Applications/Ollama.app ]; then
      open -a Ollama >/dev/null 2>&1 || true
    else
      nohup "$OLLAMA_BIN" serve >/dev/null 2>&1 &
    fi
    for _ in $(seq 1 30); do ollama_up && break; sleep 1; done
  fi

  # 3c. Model Bielik
  if [ -n "$OLLAMA_BIN" ] && ollama_up; then
    if "$OLLAMA_BIN" list 2>/dev/null | grep -qi "bielik"; then
      green "  ✓ Model Bielik już pobrany"
    else
      echo ""
      yellow "  Model Bielik waży ok. 6,7 GB. Pobranie chwilę potrwa i zajmie"
      yellow "  tyle miejsca na dysku. Potrzebujesz stabilnego łącza."
      if ask "  Pobrać teraz model Bielik?"; then
        echo "  Pobieram model (postęp poniżej)…"
        if "$OLLAMA_BIN" pull "$BIELIK_TAG"; then
          "$OLLAMA_BIN" cp "$BIELIK_TAG" bielik:latest >/dev/null 2>&1 || true
          green "  ✓ Bielik gotowy"
        else
          red "  Pobieranie modelu nie powiodło się. Zadziała tryb słownikowy."
        fi
      else
        yellow "  Pomijam model — zadziała tryb słownikowy."
      fi
    fi
  else
    yellow "  Ollama niedostępna — pomijam model. Zadziała tryb słownikowy."
  fi

else
  yellow "  Pomijam Bielika — aplikacja użyje trybu słownikowego."
fi

# ---------- 4/4  Koniec / start ----------
echo ""
echo "[4/4] Gotowe."
hr
green "  GOTOWE — instalacja zakończona."
hr
echo ""
echo "  JAK URUCHAMIAĆ PROGRAM NA CO DZIEŃ:"
echo "   • dwuklik na pliku  start.command  (w tym samym folderze),"
echo "   • otworzy się w przeglądarce pod  http://127.0.0.1:8143 ,"
echo "   • aby zatrzymać — zamknij okno Terminala."
echo ""
echo "  PRZY PRACY Z AI:"
echo "   • do modelu wklejaj wyłącznie tekst z tokenami,"
echo "   • plik  …_mapowanie.json  to klucz do danych — trzymaj go bezpiecznie"
echo "     i nigdy nie wysyłaj do AI."
echo ""
hr
if [ "$NO_LAUNCH" = "1" ]; then
  echo "  (tryb testowy — nie uruchamiam aplikacji)"
  exit 0
fi
echo ""
echo "  Uruchamiam teraz Anonimizator →  http://127.0.0.1:8143"
echo "  (przeglądarka otworzy się za chwilę; to okno zostaw otwarte)"
echo ""
exec env ANON_OPEN=1 ./.venv/bin/python app.py

"""Odczyt i zapis plików: TXT, PDF (odczyt), DOCX (odczyt + zapis z zachowaniem
formatowania).

DOCX obsługujemy na bibliotece standardowej (zipfile + ElementTree), bez
kompilowanych zależności. Tekst wyciągamy z węzłów <w:t> dokumentu, zachowując
mapowanie pozycja-w-tekście -> węzeł, dzięki czemu po anonimizacji odtwarzamy
plik z oryginalnym układem (akapity, tabele, style).

Uwaga: anonimizowana jest treść głównego dokumentu (word/document.xml).
Nagłówki/stopki nie są na razie przetwarzane.
"""

import io
import re
import xml.etree.ElementTree as ET
import zipfile

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_T = "{%s}t" % W_NS
_P = "{%s}p" % W_NS
_TAB = "{%s}tab" % W_NS
_BR = "{%s}br" % W_NS


# --------------------------------------------------------------------------
# TXT / PDF
# --------------------------------------------------------------------------

def read_txt(data: bytes) -> str:
    for enc in ("utf-8", "utf-8-sig", "cp1250", "iso-8859-2", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def read_pdf(data: bytes) -> str:
    from pypdf import PdfReader  # import leniwy — zależność tylko dla PDF
    reader = PdfReader(io.BytesIO(data))
    pages = []
    for page in reader.pages:
        pages.append(page.extract_text() or "")
    return "\n\n".join(pages)


# --------------------------------------------------------------------------
# DOCX
# --------------------------------------------------------------------------

def _register_namespaces(raw_xml: bytes):
    """Rejestruje prefiksy przestrzeni nazw z nagłówka XML, by zapis zachował
    oryginalne prefiksy (w:, r:, mc: ...) zamiast ns0, ns1..."""
    head = raw_xml[:4000].decode("utf-8", errors="replace")
    for prefix, uri in re.findall(r'xmlns:([\w\-]+)\s*=\s*"([^"]+)"', head):
        try:
            ET.register_namespace(prefix, uri)
        except Exception:
            pass
    m = re.search(r'xmlns\s*=\s*"([^"]+)"', head)
    if m:
        try:
            ET.register_namespace("", m.group(1))
        except Exception:
            pass


def _walk(el, nodes, full, state):
    """Rekurencyjny przebieg: zbiera węzły <w:t> w kolejności dokumentu,
    wstawia '\\n' na granicach akapitów oraz dla <w:br>/<w:tab>."""
    tag = el.tag
    if tag == _P:
        if state["started"]:
            full.append("\n")
            state["pos"] += 1
        state["started"] = True
    if tag == _T:
        txt = el.text or ""
        start = state["pos"]
        full.append(txt)
        state["pos"] += len(txt)
        nodes.append({"el": el, "start": start, "end": state["pos"]})
        return
    if tag == _BR:
        full.append("\n")
        state["pos"] += 1
    if tag == _TAB:
        full.append("\t")
        state["pos"] += 1
    for child in el:
        _walk(child, nodes, full, state)


def _extract(data: bytes):
    """Zwraca (full_text, tree, nodes, raw_xml)."""
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        raw_xml = z.read("word/document.xml")
    _register_namespaces(raw_xml)
    tree = ET.fromstring(raw_xml)
    nodes, full = [], []
    _walk(tree, nodes, full, {"pos": 0, "started": False})
    return "".join(full), tree, nodes, raw_xml


def read_docx(data: bytes) -> str:
    """Sam tekst (do wykrywania)."""
    return _extract(data)[0]


def docx_rebuild(data: bytes, spans) -> bytes:
    """Buduje nowy plik DOCX z tokenami w miejsce wykrytych danych.

    spans muszą mieć 'start','end' (pozycje w full_text z read_docx/_extract)
    oraz 'token'. Re-parsujemy oryginał, więc funkcja nie modyfikuje stanu
    współdzielonego i jest idempotentna.
    """
    full_text, tree, nodes, _ = _extract(data)
    spans = sorted((s for s in spans if "token" in s), key=lambda s: s["start"])

    n = len(full_text)
    starts = {}
    covered = bytearray(n)
    for s in spans:
        st, en = s["start"], min(s["end"], n)
        if st >= n or st >= en:
            continue
        starts[st] = s
        for k in range(st, en):
            covered[k] = 1

    # Przepisz tekst każdego węzła <w:t>, wstawiając tokeny i usuwając zasłonięte znaki.
    for node in nodes:
        a, b = node["start"], node["end"]
        out, i = [], a
        while i < b:
            if i in starts:
                out.append(starts[i]["token"])
                i = starts[i]["end"]
                continue
            if covered[i]:
                i += 1
                continue
            out.append(full_text[i])
            i += 1
        new_text = "".join(out)
        if new_text != (node["el"].text or ""):
            node["el"].text = new_text
            # zachowaj spacje wiodące/końcowe w tokenach
            node["el"].set("{http://www.w3.org/XML/1998/namespace}space", "preserve")

    new_document = ET.tostring(tree, encoding="utf-8", xml_declaration=True)

    out_buf = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(data)) as zin, \
            zipfile.ZipFile(out_buf, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            content = zin.read(item.filename)
            if item.filename == "word/document.xml":
                content = new_document
            zout.writestr(item, content)
    return out_buf.getvalue()


# --------------------------------------------------------------------------
# Wykrywanie typu i odczyt uniwersalny
# --------------------------------------------------------------------------

def detect_kind(filename: str, data: bytes) -> str:
    name = (filename or "").lower()
    if name.endswith(".docx") or data[:2] == b"PK" and b"word/document.xml" in data[:4000] + data[-4000:]:
        if name.endswith(".docx") or _looks_docx(data):
            return "docx"
    if name.endswith(".pdf") or data[:5] == b"%PDF-":
        return "pdf"
    return "txt"


def _looks_docx(data: bytes) -> bool:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            return "word/document.xml" in z.namelist()
    except Exception:
        return False


def read_any(filename: str, data: bytes):
    """Zwraca (kind, full_text)."""
    kind = detect_kind(filename, data)
    if kind == "docx":
        return "docx", read_docx(data)
    if kind == "pdf":
        return "pdf", read_pdf(data)
    return "txt", read_txt(data)

"""Wykrywanie osób, organizacji, adresów i miejscowości przez lokalny model
Bielik uruchomiony w Ollamie (http://localhost:11434).

Wszystko dzieje się lokalnie — tekst nie opuszcza komputera. Model radzi sobie
z odmianą polską (Kowalski / Kowalskiego / Kowalskiemu), a dodatkowa ekspansja
końcówek nazwisk dołapuje formy, które model pominął. Gdy Ollama jest
niedostępna, anonimizator korzysta z trybu awaryjnego (engine/dictionaries.py).
"""

import json
import re
import urllib.error
import urllib.request

from .dictionaries import FIRST_NAMES

OLLAMA_URL = "http://localhost:11434"
DEFAULT_MODEL = "bielik:latest"

# Maksymalny rozmiar fragmentu wysyłanego do modelu (znaki).
_CHUNK = 1600

_TYP_NA_KATEGORIE = {
    "osoba": "OSOBA", "osoby": "OSOBA", "person": "OSOBA",
    "organizacja": "FIRMA", "organizacje": "FIRMA", "firma": "FIRMA",
    "instytucja": "FIRMA",
    "adres": "ADRES", "ulica": "ADRES",
    "miejscowosc": "MIEJSCE", "miejscowość": "MIEJSCE",
    "miasto": "MIEJSCE", "miejsce": "MIEJSCE",
}

_PROMPT = """Jesteś precyzyjnym systemem rozpoznawania danych osobowych (NER) w języku polskim.
Wypisz z tekstu wszystkie: osoby, organizacje/firmy, adresy (ulica z numerem) i miejscowości.

ZASADY:
1. Każda odrębna osoba/firma/miejsce to OSOBNY obiekt na liście.
2. W polu "formy" podaj wszystkie formy danej encji obecne w tekście, dokładnie jak zapisane,
   łącznie z odmianą (np. "Jana Kowalskiego", "Kowalskiemu", "Kowalski").
3. Nie wymyślaj danych, których nie ma w tekście. Zwróć wyłącznie JSON, bez komentarzy.

PRZYKŁAD
Tekst: "Spotkałem Jana Kowalskiego w firmie Stalbud. Później Kowalski pojechał do Gdańska."
Wynik: {"encje":[{"typ":"osoba","formy":["Jana Kowalskiego","Kowalski"]},{"typ":"organizacja","formy":["Stalbud"]},{"typ":"miejscowosc","formy":["Gdańska"]}]}

Format wyniku:
{"encje": [{"typ": "osoba|organizacja|adres|miejscowosc", "formy": ["...", "..."]}]}

TEKST:
\"\"\"
%s
\"\"\"
"""

# Końcówki przymiotnikowych nazwisk (-ski/-cki/-dzki i formy żeńskie).
_ADJ = ("ski", "cki", "dzki", "ska", "cka", "dzka")


# --------------------------------------------------------------------------
# Komunikacja z Ollamą
# --------------------------------------------------------------------------

def _post(path, payload, timeout):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_URL + path, data=data,
        headers={"Content-Type": "application/json"}, method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def list_models():
    try:
        req = urllib.request.Request(OLLAMA_URL + "/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=4) as r:
            tags = json.loads(r.read().decode("utf-8"))
        return [m.get("name", "") for m in tags.get("models", [])]
    except Exception:
        return []


def find_bielik_model():
    """Zwraca nazwę zainstalowanego tagu Bielika (dowolnego) albo None.

    Dzięki temu działa zarówno z aliasem 'bielik:latest', jak i z surowym tagiem
    'SpeakLeash/bielik-11b-v3.0-instruct:Q4_K_M' po świeżym `ollama pull`.
    """
    models = list_models()
    for m in models:
        if m == DEFAULT_MODEL:
            return m
    for m in models:
        if "bielik" in m.lower():
            return m
    return None


def available(model=None) -> bool:
    """Czy Ollama działa i czy jest dostępny model (konkretny lub jakikolwiek Bielik)."""
    if model:
        base = model.split(":")[0]
        return any(m == model or m.split(":")[0] == base for m in list_models())
    return find_bielik_model() is not None


# --------------------------------------------------------------------------
# Pomocnicze
# --------------------------------------------------------------------------

def _chunks(text: str):
    if len(text) <= _CHUNK:
        yield text
        return
    pos, n = 0, len(text)
    while pos < n:
        end = min(pos + _CHUNK, n)
        if end < n:
            brk = text.rfind("\n", pos, end)
            if brk == -1 or brk <= pos + 200:
                brk = text.rfind(" ", pos, end)
            if brk > pos:
                end = brk
        yield text[pos:end]
        pos = end


def _parse_entities(raw: str):
    raw = (raw or "").strip()
    try:
        obj = json.loads(raw)
    except Exception:
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        if not m:
            return []
        try:
            obj = json.loads(m.group(0))
        except Exception:
            return []
    encje = obj.get("encje") if isinstance(obj, dict) else None
    return encje if isinstance(encje, list) else []


def _surnames_in(form: str):
    """Wielkie słowa wyglądające na nazwisko (z pominięciem znanych imion)."""
    out = []
    for tok in re.findall(r"[^\W\d_]+", form, re.UNICODE):
        if len(tok) >= 4 and tok[0].isupper() and tok.lower() not in FIRST_NAMES:
            out.append(tok)
    return out


def _surname_variant_regex(surname: str) -> str:
    """Wzorzec łapiący odmianę danego nazwiska."""
    low = surname.lower()
    if low.endswith(_ADJ):
        stem = surname[:-1]                      # Kowalski/Kowalska -> Kowalsk
        return re.escape(stem) + r"(?:i|a|iego|iej|iemu|im|ich|ie|ą|ę|imi)"
    # nazwiska rzeczownikowe: Nowak, Wójcik, Kowal...
    return re.escape(surname) + r"(?:a|owi|iem|u|owie|ów|om|ami|owa|ową)?"


def _stem(word: str) -> str:
    """Sprowadza nazwisko do rdzenia, by scalić formy odmienione.

    Kowalski/Kowalskiego/Kowalskiemu -> kowalsk ; Nowak/Nowaka/Nowakowi -> nowak
    """
    low = word.lower()
    for core in ("dzk", "ck", "sk"):
        i = low.rfind(core)
        if i != -1 and i >= len(low) - 6:
            return low[:i + len(core)]
    for suf in ("owie", "ami", "iem", "owi", "ów", "om", "ego", "emu",
                "ie", "ą", "ę", "a", "u", "e", "y", "i"):
        if low.endswith(suf) and len(low) - len(suf) >= 3:
            return low[:-len(suf)]
    return low


def _signature(category: str, forms):
    """Klucz scalający formy tej samej encji (spójny token w całym dokumencie)."""
    longest = max(forms, key=len)
    if category == "OSOBA":
        surs = _surnames_in(longest)
        if surs:
            return "OSOBA::" + _stem(surs[-1])
        toks = longest.split()
        return "OSOBA::" + _stem(toks[-1]) if toks else "OSOBA::" + longest.lower()
    return category + "::" + longest.lower()


def _entity_pattern(category: str, forms):
    forms_sorted = sorted({f.strip() for f in forms if isinstance(f, str) and len(f.strip()) >= 3},
                          key=len, reverse=True)
    if not forms_sorted:
        return None
    parts = [re.escape(f) for f in forms_sorted]
    if category == "OSOBA":
        seen = set()
        for f in forms_sorted:
            for sur in _surnames_in(f):
                if sur.lower() not in seen:
                    seen.add(sur.lower())
                    parts.append(_surname_variant_regex(sur))
    return re.compile(r"(?<![\w])(?:" + "|".join(parts) + r")(?![\w])", re.UNICODE)


# --------------------------------------------------------------------------
# Główna funkcja
# --------------------------------------------------------------------------

def detect_entities(text: str, model=None, enabled=None, progress=None):
    """Zwraca listę spanów {start,end,surface,category,source,group}."""
    model = model or find_bielik_model() or DEFAULT_MODEL
    chunk_list = list(_chunks(text))
    total = len(chunk_list)
    raw = []  # (category, [forms])

    for idx, chunk in enumerate(chunk_list):
        if progress:
            progress(idx, total)
        try:
            resp = _post("/api/generate", {
                "model": model,
                "prompt": _PROMPT % chunk,
                "stream": False,
                "format": "json",
                "options": {"temperature": 0, "num_ctx": 4096, "num_predict": 2048},
            }, timeout=240)
        except (urllib.error.URLError, TimeoutError, OSError):
            continue
        for ent in _parse_entities(resp.get("response", "")):
            if not isinstance(ent, dict):
                continue
            category = _TYP_NA_KATEGORIE.get(str(ent.get("typ", "")).lower().strip())
            if category is None:
                continue
            if enabled is not None and category not in enabled:
                continue
            forms = ent.get("formy") or ([ent["tekst"]] if ent.get("tekst") else [])
            forms = [f for f in forms if isinstance(f, str) and f.strip()]
            if forms:
                raw.append((category, forms))

    # Scal encje z całego dokumentu (ten sam człowiek -> jedna grupa -> jeden token).
    # Osoby grupujemy per-forma po rdzeniu nazwiska, bo model bywa zlewa różnych
    # ludzi w jedną encję — my je rozdzielamy niezależnie od tego.
    merged = {}
    for category, forms in raw:
        if category == "OSOBA":
            for f in forms:
                sig = _signature("OSOBA", [f])
                merged.setdefault(sig, {"category": "OSOBA", "forms": set()})["forms"].add(f)
        else:
            sig = _signature(category, forms)
            merged.setdefault(sig, {"category": category, "forms": set()})["forms"].update(forms)

    # Zlokalizuj wszystkie wystąpienia (z odmianą) w pełnym tekście
    spans, seen_spans = [], set()
    for gi, (sig, info) in enumerate(merged.items(), start=1):
        pat = _entity_pattern(info["category"], info["forms"])
        if pat is None:
            continue
        group = "%s#%d" % (info["category"], gi)
        for mt in pat.finditer(text):
            key = (mt.start(), mt.end())
            if key in seen_spans:
                continue
            seen_spans.add(key)
            spans.append({
                "start": mt.start(), "end": mt.end(),
                "surface": text[mt.start():mt.end()],
                "category": info["category"], "source": "bielik", "group": group,
            })

    if progress:
        progress(total, total)
    return spans

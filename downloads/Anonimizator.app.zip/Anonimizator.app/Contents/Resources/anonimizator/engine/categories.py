"""Definicje kategorii danych wykrywanych przez anonimizator.

Każda kategoria ma:
- prefix  -> prefiks tokenu w tekście, np. PESEL -> [PESEL_1]
- label   -> etykieta po polsku (interfejs)
- default -> czy domyślnie zaznaczona do anonimizacji
- source  -> 'regex' (deterministyczne) albo 'ner' (model / słowniki)
"""

CATEGORY_META = {
    # --- dane wykrywane przez NER (Bielik) lub słowniki ---
    "OSOBA":        {"prefix": "OSOBA",    "label": "Imię i nazwisko / osoba", "default": True,  "source": "ner"},
    "NAZWISKO":     {"prefix": "NAZWISKO", "label": "Nazwisko",                "default": True,  "source": "ner"},
    "IMIE":         {"prefix": "IMIE",     "label": "Imię",                    "default": True,  "source": "ner"},
    "FIRMA":        {"prefix": "FIRMA",    "label": "Organizacja / firma",     "default": True,  "source": "ner"},
    "ADRES":        {"prefix": "ADRES",    "label": "Adres / ulica",           "default": True,  "source": "ner"},
    "MIEJSCE":      {"prefix": "MIEJSCE",  "label": "Miasto / miejscowość",    "default": True,  "source": "ner"},

    # --- dane wykrywane deterministycznie (regex + sumy kontrolne) ---
    "PESEL":        {"prefix": "PESEL",    "label": "PESEL",                   "default": True,  "source": "regex"},
    "NIP":          {"prefix": "NIP",      "label": "NIP",                     "default": True,  "source": "regex"},
    "REGON":        {"prefix": "REGON",    "label": "REGON",                   "default": True,  "source": "regex"},
    "DOWOD":        {"prefix": "DOWOD",    "label": "Nr dowodu osobistego",    "default": True,  "source": "regex"},
    "PASZPORT":     {"prefix": "PASZPORT", "label": "Nr paszportu",            "default": True,  "source": "regex"},
    "IBAN":         {"prefix": "KONTO",    "label": "Nr konta / IBAN",         "default": True,  "source": "regex"},
    "TELEFON":      {"prefix": "TELEFON",  "label": "Telefon",                 "default": True,  "source": "regex"},
    "EMAIL":        {"prefix": "EMAIL",    "label": "E-mail",                  "default": True,  "source": "regex"},
    "KOD_POCZTOWY": {"prefix": "KOD",      "label": "Kod pocztowy",            "default": True,  "source": "regex"},
    "KRS":          {"prefix": "KRS",      "label": "Nr KRS",                  "default": True,  "source": "regex"},
    "DATA":         {"prefix": "DATA",     "label": "Data",                    "default": False, "source": "regex"},
    "TABLICA":      {"prefix": "TABLICA",  "label": "Tablica rejestracyjna",   "default": False, "source": "regex"},

    # --- maski dodane ręcznie przez użytkownika ---
    "INNE":         {"prefix": "INNE",     "label": "Inne / ręczne",           "default": True,  "source": "manual"},
}

# Priorytet przy nakładaniu się dopasowań (wyższy = wygrywa).
# Twarde identyfikatory mają pierwszeństwo przed nazwami z modelu.
PRIORITY = {
    "INNE": 110,                       # ręczne maski mają pierwszeństwo
    "PESEL": 100, "IBAN": 95, "NIP": 90, "REGON": 85, "KRS": 84,
    "DOWOD": 80, "PASZPORT": 78, "EMAIL": 70, "TELEFON": 60,
    "KOD_POCZTOWY": 55, "DATA": 50, "TABLICA": 45,
    "OSOBA": 40, "NAZWISKO": 38, "IMIE": 36, "FIRMA": 34, "ADRES": 32, "MIEJSCE": 30,
}


def default_enabled():
    """Zwraca zbiór kategorii domyślnie włączonych."""
    return {k for k, v in CATEGORY_META.items() if v["default"]}

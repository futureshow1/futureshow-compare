"""Słownikowe wykrywanie imion i nazwisk — tryb awaryjny bez modelu.

Używane, gdy Bielik/Ollama jest niedostępny albo wyłączony. Działa na formach
mianownikowych imion oraz na heurystyce końcówek nazwisk (-ski, -cki, -wicz...).
Nie obsługuje pełnej odmiany — od tego jest Bielik.
"""

import re

# Najczęstsze polskie imiona (mianownik). Lista celowo zwięzła, ale pokrywa
# zdecydowaną większość realnych dokumentów.
FIRST_NAMES = {
    # męskie
    "adam", "adrian", "albert", "aleksander", "aleksy", "alan", "andrzej", "antoni",
    "arkadiusz", "artur", "bartłomiej", "bartosz", "błażej", "bogdan", "bogusław",
    "bolesław", "borys", "cezary", "czesław", "damian", "daniel", "dariusz", "dawid",
    "dominik", "edward", "emil", "erik", "eryk", "eugeniusz", "fabian", "feliks",
    "filip", "franciszek", "gabriel", "grzegorz", "gustaw", "henryk", "hubert",
    "ignacy", "igor", "jacek", "jakub", "jan", "janusz", "jarosław", "jerzy",
    "józef", "kacper", "kamil", "karol", "kazimierz", "konrad", "krystian",
    "krzysztof", "leszek", "lech", "leon", "lucjan", "ludwik", "łukasz", "maciej",
    "marcin", "marek", "marian", "mariusz", "mateusz", "michał", "mikołaj",
    "mirosław", "norbert", "oskar", "olgierd", "patryk", "paweł", "piotr", "przemysław",
    "rafał", "radosław", "remigiusz", "robert", "roman", "ryszard", "sebastian",
    "sławomir", "stanisław", "stefan", "szymon", "tadeusz", "tomasz", "wacław",
    "waldemar", "wiktor", "witold", "władysław", "włodzimierz", "wojciech",
    "zbigniew", "zdzisław", "zygmunt",
    # żeńskie
    "ada", "adrianna", "agata", "agnieszka", "aldona", "aleksandra", "alicja",
    "alina", "amelia", "aneta", "angelika", "anna", "antonina", "barbara",
    "beata", "bogna", "bożena", "danuta", "daria", "dominika", "dorota", "edyta",
    "elżbieta", "emilia", "ewa", "ewelina", "gabriela", "genowefa", "grażyna",
    "halina", "hanna", "helena", "iga", "ilona", "irena", "iwona", "izabela",
    "jadwiga", "joanna", "jolanta", "julia", "justyna", "kamila", "karolina",
    "katarzyna", "kinga", "klaudia", "kornelia", "krystyna", "laura", "lena",
    "lidia", "liliana", "łucja", "magdalena", "maja", "małgorzata", "marcelina",
    "maria", "marianna", "marlena", "marta", "martyna", "marzena", "milena",
    "monika", "nadia", "natalia", "nikola", "oliwia", "olga", "patrycja", "paulina",
    "renata", "róża", "sandra", "sara", "stanisława", "stefania", "sylwia",
    "teresa", "urszula", "wanda", "weronika", "wiktoria", "wiesława", "zofia",
    "zuzanna",
}

# Końcówki silnie wskazujące na polskie nazwisko (z formami odmienionymi).
_SURNAME_SUFFIXES = (
    "ski", "ska", "scy", "skie", "skich", "skiego", "skiej", "skim", "skiemu", "ską",
    "cki", "cka", "ccy", "ckie", "ckiego", "ckiej", "ckim", "ckiemu", "cką",
    "dzki", "dzka", "dzkie", "dzcy", "dzkiego", "dzkiemu", "dzkim",
    "ński", "ńska", "ńskiego", "ńskiej", "ńskiemu", "ńskim", "ńskich",
    "wicz", "wiczowa", "wiczem", "czyk", "czyka", "czykiem",
)

# Najczęstsze polskie nazwiska (formy podstawowe). Dopasowanie po rdzeniu łapie
# też odmianę (Nowaka, Kowalskiemu, Dąbrowską). Pominięto formy będące zarazem
# pospolitymi wyrazami (król, lis, wilk, mazur…), by ograniczyć fałszywe trafienia.
COMMON_SURNAMES = {
    "nowak", "kowalski", "wiśniewski", "wójcik", "kowalczyk", "kamiński",
    "lewandowski", "zieliński", "szymański", "woźniak", "dąbrowski", "kozłowski",
    "jankowski", "wojciechowski", "kwiatkowski", "krawczyk", "kaczmarek",
    "piotrowski", "grabowski", "pawłowski", "michalski", "nowakowski", "wieczorek",
    "jabłoński", "wróbel", "majewski", "stępień", "górski", "nowicki", "adamczyk",
    "dudek", "pawlak", "witkowski", "walczak", "rutkowski", "michalak", "szewczyk",
    "ostrowski", "tomaszewski", "pietrzak", "marciniak", "wróblewski", "zalewski",
    "jakubowski", "jasiński", "sadowski", "chmielewski", "włodarczyk", "borkowski",
    "czarnecki", "sawicki", "sokołowski", "urbański", "kubiak", "maciejewski",
    "szczepański", "kucharski", "kalinowski", "mazurek", "wysocki", "adamski",
    "kaźmierczak", "wasilewski", "sobczak", "czerwiński", "andrzejewski", "cieślak",
    "głowacki", "zawadzki", "brzeziński", "janik", "łuczak", "kołodziej",
    "urbaniak", "krajewski", "kaczmarczyk", "sikorski", "lipiński", "mróz",
    "domański", "zięba", "borowski", "wilczek", "tomczak", "kucharczyk",
    "olszewski", "kaczor", "kowal", "kołodziejczyk", "malinowski", "kasprzak",
    "duda", "szulc", "modrzejewski", "kozioł", "głowacz", "laskowski", "kowalewski",
    "śliwiński", "jaworski", "wawrzyniak", "jarosz", "polak",
    "augustyniak", "kołodziejski", "sobolewski", "dębski", "muszyński",
}

_WORD = re.compile(r"[^\W\d_]+(?:[-'][^\W\d_]+)*", re.UNICODE)


def _is_capitalized(w: str) -> bool:
    """Pierwsza litera wielka, ale nie cały wyraz wielkimi (to byłby akronim)."""
    return len(w) > 1 and w[0].isupper() and not w.isupper()


def _stem(word: str) -> str:
    """Rdzeń wyrazu — by dopasować odmienione nazwiska (Nowaka→nowak, Kowalskiemu→kowalsk)."""
    low = word.lower()
    for core in ("dzk", "ck", "sk"):
        i = low.rfind(core)
        if i != -1 and i >= len(low) - 6:
            return low[:i + len(core)]
    for suf in ("owie", "ami", "iem", "owi", "ego", "emu", "ów", "om",
                "ie", "a", "u", "e", "ę", "ą", "y", "i"):
        if low.endswith(suf) and len(low) - len(suf) >= 3:
            return low[:-len(suf)]
    return low


_COMMON_SURNAME_STEMS = {_stem(s) for s in COMMON_SURNAMES}


def _looks_like_surname(low: str) -> bool:
    if len(low) >= 5 and low.endswith(_SURNAME_SUFFIXES):
        return True
    if low in COMMON_SURNAMES:
        return True
    st = _stem(low)
    return len(st) >= 4 and st in _COMMON_SURNAME_STEMS


def find_names_dict(text: str, enabled=None):
    """Heurystyczne wykrywanie osób na bazie słownika imion i końcówek nazwisk."""
    want_osoba = enabled is None or "OSOBA" in enabled
    want_imie = enabled is None or "IMIE" in enabled
    want_nazwisko = enabled is None or "NAZWISKO" in enabled
    if not (want_osoba or want_imie or want_nazwisko):
        return []

    toks = list(_WORD.finditer(text))
    out = []
    consumed = set()

    for i, m in enumerate(toks):
        if i in consumed:
            continue
        w = m.group()
        low = w.lower()

        if low in FIRST_NAMES and _is_capitalized(w):
            nxt = toks[i + 1] if i + 1 < len(toks) else None
            joined_close = nxt is not None and (nxt.start() - m.end()) <= 1
            nxt_is_name = nxt is not None and _is_capitalized(nxt.group())
            # imię + (nazwisko / kolejne wielkie słowo) -> cała osoba
            if joined_close and nxt_is_name and nxt.group().lower() not in FIRST_NAMES:
                if want_osoba:
                    out.append(_span(m.start(), nxt.end(), text, "OSOBA"))
                    consumed.add(i + 1)
                elif want_imie:
                    out.append(_span(m.start(), m.end(), text, "IMIE"))
            elif want_imie:
                out.append(_span(m.start(), m.end(), text, "IMIE"))

        elif _is_capitalized(w) and _looks_like_surname(low) and want_nazwisko:
            out.append(_span(m.start(), m.end(), text, "NAZWISKO"))

    return out


def _span(start, end, text, category):
    return {
        "start": start,
        "end": end,
        "surface": text[start:end],
        "category": category,
        "source": "dict",
    }

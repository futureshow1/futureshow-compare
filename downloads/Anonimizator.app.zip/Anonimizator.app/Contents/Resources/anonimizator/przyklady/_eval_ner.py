"""Porównanie jakości wykrywania OSÓB między silnikami (słownik vs warianty Bielika).

Metryka kluczowa dla anonimizacji = RECALL na osobach (pominięte = wyciek).
Uruchom: _eval_ner.py [engine ...]   gdzie engine = 'dict' albo nazwa modelu Ollamy.
"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine import dictionaries, ner_bielik

CASES = [
    {
        "text": ("W dniu wczorajszym mediator Piotr Wiśniewski spotkał się z Janem Kowalskim "
                 "oraz panią Anną Nowak. Kowalskiemu zależało na ugodzie, natomiast Nowak "
                 "wniosła zastrzeżenia. Sprawę nadzoruje Sąd Rejonowy w Krakowie. "
                 "Pełnomocnikiem pani Dąbrowskiej jest mecenas Tomasz Lewandowski."),
        "persons": ["Piotr Wiśniewski", "Janem Kowalskim", "Anną Nowak", "Kowalskiemu",
                    "Nowak", "Dąbrowskiej", "Tomasz Lewandowski"],
    },
    {
        "text": ("Zeznania złożyła Aleksandra Wójcik. Przesłuchano też Krzysztofa Zielińskiego, "
                 "który mieszka we Wrocławiu, oraz Marię Dąbrowską z Poznania. "
                 "Później Zieliński zmienił zeznania."),
        "persons": ["Aleksandra Wójcik", "Krzysztofa Zielińskiego", "Marię Dąbrowską", "Zieliński"],
    },
]


def person_surfaces(spans):
    return [s["surface"] for s in spans if s.get("category") in ("OSOBA", "IMIE", "NAZWISKO")]


def covered(gold, surfaces):
    g = gold.lower()
    return any(g in s.lower() or s.lower() in g for s in surfaces)


def detect(engine, text):
    if engine == "dict":
        return dictionaries.find_names_dict(text)
    return ner_bielik.detect_entities(text, model=engine)


def main():
    engines = sys.argv[1:] or ["dict", "bielik:latest"]
    rows = []
    for eng in engines:
        t0 = time.time(); caught = 0; total = 0; missed = []
        for c in CASES:
            surf = person_surfaces(detect(eng, c["text"]))
            for g in c["persons"]:
                total += 1
                if covered(g, surf):
                    caught += 1
                else:
                    missed.append(g)
        rows.append((eng, caught, total, missed, time.time() - t0))

    print("\n%-48s %-15s %-7s %s" % ("SILNIK", "OSOBY (recall)", "czas", "POMINIĘTE"))
    print("-" * 105)
    for eng, caught, total, missed, dt in rows:
        rec = "%d/%d (%d%%)" % (caught, total, round(100 * caught / total))
        print("%-48s %-15s %5.1fs  %s" % (eng, rec, dt, ", ".join(missed) or "—"))


main()

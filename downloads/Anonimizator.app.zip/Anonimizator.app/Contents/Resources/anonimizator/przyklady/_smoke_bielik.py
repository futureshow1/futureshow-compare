import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine import ner_bielik

print("Ollama dostępna / model jest:", ner_bielik.available())
print("Modele:", ner_bielik.list_models())

t = ("Pani Anna Nowak mieszka w Krakowie przy ulicy Długiej 7. "
     "Sprawę przeciwko Kowalskiemu prowadzi mecenas Piotr Wiśniewski "
     "z kancelarii Lex Sp. z o.o. Pozwany Jan Kowalski nie stawił się.")

t0 = time.time()
spans = ner_bielik.detect_entities(t)
print("czas: %.1fs, spanów: %d" % (time.time() - t0, len(spans)))
for s in spans:
    print("  %-9s %-8s %r" % (s["category"], s["group"], s["surface"]))

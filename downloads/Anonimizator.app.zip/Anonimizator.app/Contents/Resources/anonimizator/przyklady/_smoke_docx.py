import sys, os, io, zipfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine import anonymizer, io_files

CT = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>'''

RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>'''

# "Jan Kowalski" celowo rozbite na dwa runy.
DOC = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body>
<w:p><w:r><w:t xml:space="preserve">Strona: Jan </w:t></w:r><w:r><w:t>Kowalski, PESEL 44051401359.</w:t></w:r></w:p>
<w:p><w:r><w:t>Adres: ul. Kwiatowa 5. Tel +48 601 234 567.</w:t></w:r></w:p>
</w:body>
</w:document>'''


def make_docx():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CT)
        z.writestr("_rels/.rels", RELS)
        z.writestr("word/document.xml", DOC)
    return buf.getvalue()


data = make_docx()
here = os.path.dirname(os.path.abspath(__file__))
open(os.path.join(here, "test.docx"), "wb").write(data)

text = io_files.read_docx(data)
print("=== TEKST Z DOCX ===")
print(repr(text))

spans, info = anonymizer.detect(text, use_bielik=False)   # szybko, deterministycznie
_, mapping, spans = anonymizer.anonymize(text, spans)
print("\n=== MAPOWANIE ===")
for tok, v in mapping.items():
    print(" ", tok, "->", v["canonical"])

new_data = io_files.docx_rebuild(data, spans)
open(os.path.join(here, "test_anon.docx"), "wb").write(new_data)

text2 = io_files.read_docx(new_data)
print("\n=== TEKST PO ANONIMIZACJI (z odbudowanego DOCX) ===")
print(repr(text2))

with zipfile.ZipFile(io.BytesIO(new_data)) as z:
    bad = z.testzip()
    print("\nZIP poprawny:", bad is None, "| pliki:", z.namelist())

leaks = [w for w in ("Kowalski", "44051401359", "Kwiatowa", "601 234 567") if w in text2]
print("WYCIEKI w wyniku:", leaks if leaks else "BRAK")
print("Tokeny obecne:", all(t in text2 for t in ("[OSOBA_1]", "[PESEL_1]")))
